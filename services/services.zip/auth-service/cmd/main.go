package main

import (
	"log"
	"os"
	"time"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	jwtware "github.com/gofiber/jwt/v3"
	"github.com/joho/godotenv"

	"github.com/lyagu5h/auth-service/internal/infrastructure/db"
	"github.com/lyagu5h/auth-service/internal/interface/httpapi"
	"github.com/lyagu5h/auth-service/internal/repository"
	"github.com/lyagu5h/auth-service/internal/usecase"
)

func main() {
	_ = godotenv.Load()

	secret := []byte(os.Getenv("JWT_SECRET"))
	if len(secret) == 0 {
		log.Fatal("JWT_SECRET not set")
	}
	pg := db.NewPostgresDB()
	defer pg.Close()
	_ = db.RunMigrations(pg, "./migrations")

	uc := usecase.NewAuthUseCase(repository.NewUserRepo(pg), secret, 8*time.Hour)
	h  := httpapi.NewAuthHandler(uc, validator.New())

	app := fiber.New()
	app.Use(cors.New())

	app.Post("/auth/register", h.Register)
	app.Post("/auth/login",    h.Login)

	app.Get("/auth/me", jwtware.New(jwtware.Config{
		SigningKey:   secret,
		ContextKey:  "user",
		TokenLookup: "header:Authorization",
		SigningMethod: "HS256",
	}), h.Me)

	log.Fatal(app.Listen(":8082"))
}
