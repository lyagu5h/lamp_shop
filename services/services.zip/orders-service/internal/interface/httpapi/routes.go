package httpapi

import (
	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"github.com/lyagu5h/orders-service/internal/usecase"
)

func RegisterRoutes(app *fiber.App, orderUC *usecase.OrderUseCase, validate *validator.Validate, auth fiber.Handler, admin fiber.Handler) {
    handler := NewOrderHandler(orderUC, validate)
    grp := app.Group("/orders", auth)
    grp.Get("/", handler.List)
    grp.Get("/:id", handler.Get)
    grp.Post("/", handler.Create)
    grp.Use(admin)
    grp.Patch("/:id/status", handler.UpdateStatus)
}