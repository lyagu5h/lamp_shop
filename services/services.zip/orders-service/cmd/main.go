package main

import (
	"log"
	"os"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	jwtware "github.com/gofiber/jwt/v3"
	"github.com/golang-jwt/jwt/v5"
	"github.com/joho/godotenv"

	db "github.com/lyagu5h/orders-service/internal/infrastructure/db"
	"github.com/lyagu5h/orders-service/internal/interface/httpapi"
	orderRepo "github.com/lyagu5h/orders-service/internal/repository"
	"github.com/lyagu5h/orders-service/internal/usecase"
)

func main() {
    if err := godotenv.Load(); err != nil {
        log.Println("warning: .env file not found or could not be loaded")
    }

	dbConn := db.NewPostgresDB()
	defer dbConn.Close()

	if err := db.RunMigration(dbConn, "./migrations"); err != nil {
		log.Fatalf("goose up (orders) failed: %v", err)
	}
    
    orderRepo := orderRepo.NewOrderRepo(dbConn)
    orderUC := usecase.NewOrderUseCase(orderRepo)

    app := fiber.New()
    validate := validator.New()

	app.Use(cors.New(cors.Config{
        AllowOrigins: "*",
        AllowMethods: "GET,POST,PUT,PATCH,DELETE,OPTIONS",
        AllowHeaders: "Origin, Content-Type, Accept, Authorization",
    }))


    secret := []byte(os.Getenv("JWT_SECRET"))

    authMW := jwtware.New(jwtware.Config{
        SigningKey: secret,
        ContextKey: "user",
    })

    adminOnly := func(c *fiber.Ctx) error {
        claims := c.Locals("user").(*jwt.Token).Claims.(jwt.MapClaims)
        if claims["role"] != "admin" {
            return c.Status(fiber.StatusForbidden).
                JSON(fiber.Map{"error": "admin rights required"})
        }
        return c.Next()
    }

    httpapi.RegisterRoutes(app, orderUC, validate, authMW, adminOnly)

    port := os.Getenv("PORT")
    if port == "" {
        port = "8090"
    }
    log.Printf("orders-service is running on port %s", port)
    log.Fatal(app.Listen(":" + port))
}