package httpapi

import (
	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"github.com/lyagu5h/products-service/internal/usecase"
	"github.com/minio/minio-go/v7"
)

func RegisterRoutes(app *fiber.App, productUC *usecase.ProductUseCase, validate *validator.Validate, minioCli *minio.Client, bucket string, auth fiber.Handler, admin fiber.Handler) {
	handler := NewProductHandler(productUC, validate, minioCli, bucket)
	grp := app.Group("/products", auth)
	grp.Get("/", handler.List)
	grp.Get("/:id", handler.Get)
	grp.Use(admin)
	grp.Post("/", handler.Create)
	grp.Put("/:id", handler.Update)
	grp.Delete("/:id", handler.Delete)
	grp.Post("/:id/image", handler.uploadProductImage)
}